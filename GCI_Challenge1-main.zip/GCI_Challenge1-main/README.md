# GCI_Challenge1
First challenge provided by Girl Code It-MAIT 
Using HTML for adding more context to the file and simplying the design for desired output.
